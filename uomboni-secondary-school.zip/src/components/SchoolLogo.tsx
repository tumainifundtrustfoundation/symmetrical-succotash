import React from 'react';
import { useData } from '../context/DataContext';

interface SchoolLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  showText?: boolean;
  variant?: 'light' | 'dark' | 'color';
}

export const SchoolLogo: React.FC<SchoolLogoProps> = ({
  className = '',
  size = 'md',
  showText = false,
  variant = 'color'
}) => {
  const { customLogoUrl } = useData();

  const sizeMap = {
    sm: 'w-10 h-10',
    md: 'w-13 h-13',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
    '2xl': 'w-32 h-32',
  };

  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {/* Official Uomboni Crest (Custom Image if uploaded or SVG Crest) */}
      <div className={`relative shrink-0 ${sizeMap[size]}`}>
        {customLogoUrl ? (
          <img
            src={customLogoUrl}
            alt="Nembo ya Shule ya Sekondari Uomboni"
            className="w-full h-full object-contain drop-shadow-md rounded-full"
          />
        ) : (
        <svg
          viewBox="0 0 220 220"
          className="w-full h-full drop-shadow-md select-none"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Color Gradients */}
            <linearGradient id="uomboniGold" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FEF08A" />
              <stop offset="30%" stopColor="#FDE047" />
              <stop offset="70%" stopColor="#F59E0B" />
              <stop offset="100%" stopColor="#D97706" />
            </linearGradient>

            <linearGradient id="uomboniGoldLight" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FEF9C3" />
              <stop offset="50%" stopColor="#FEF08A" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>

            <linearGradient id="uomboniSky" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#BAE6FD" />
              <stop offset="50%" stopColor="#E0F2FE" />
              <stop offset="100%" stopColor="#FEF3C7" />
            </linearGradient>

            <linearGradient id="uomboniBlueShield" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#2563EB" />
              <stop offset="50%" stopColor="#1D4ED8" />
              <stop offset="100%" stopColor="#1E40AF" />
            </linearGradient>

            <linearGradient id="uomboniBlueBanner" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3B82F6" />
              <stop offset="50%" stopColor="#2563EB" />
              <stop offset="100%" stopColor="#1D4ED8" />
            </linearGradient>

            {/* Clipping Paths */}
            <clipPath id="centerEmblemClip">
              <circle cx="110" cy="102" r="54" />
            </clipPath>

            {/* Text Paths */}
            <path
              id="top-diocese-path"
              d="M 28,104 A 82,82 0 1,1 192,104"
              fill="none"
            />
            <path
              id="uomboni-arc-path"
              d="M 58,98 A 52,52 0 0,1 162,98"
              fill="none"
            />
            <path
              id="secondary-school-path"
              d="M 58,106 A 52,52 0 0,0 162,106"
              fill="none"
            />
            <path
              id="bottom-motto-path"
              d="M 38,144 C 70,172 150,172 182,144"
              fill="none"
            />
          </defs>

          {/* 1. TOP ROYAL BLUE CURVED BANNER: CATHOLIC DIOCESE OF MOSHI */}
          <path
            d="M 26 95 C 26 32, 194 32, 194 95 L 174 95 C 174 48, 46 48, 46 95 Z"
            fill="url(#uomboniBlueBanner)"
            stroke="url(#uomboniGold)"
            strokeWidth="2"
          />
          <text fontSize="10.5" fontWeight="900" fill="#FFFFFF" letterSpacing="1">
            <textPath href="#top-diocese-path" startOffset="50%" textAnchor="middle">
              CATHOLIC DIOCESE OF MOSHI
            </textPath>
          </text>

          {/* 2. MAIN BLUE CIRCLE FRAME */}
          <circle
            cx="110"
            cy="102"
            r="60"
            fill="url(#uomboniBlueShield)"
            stroke="url(#uomboniGold)"
            strokeWidth="3.5"
          />

          {/* 3. INNER CENTRAL DISC (Clipped to circle) */}
          <g clipPath="url(#centerEmblemClip)">
            {/* Sky Background */}
            <rect x="45" y="40" width="130" height="130" fill="url(#uomboniSky)" />

            {/* Mount Kilimanjaro (Lush Green with Snowcap on the Left Peak) */}
            <polygon points="52,108 88,68 126,108" fill="#15803D" stroke="#166534" strokeWidth="0.8" />
            <polygon points="105,108 135,74 165,108" fill="#166534" />
            {/* Snowy Kibo Peak */}
            <polygon points="76,82 88,68 100,82 94,86 88,83 82,86" fill="#FFFFFF" />

            {/* Holy Red Catholic Cross (Dominant Center) */}
            {/* Vertical Beam */}
            <rect x="103" y="46" width="14" height="72" fill="#DC2626" />
            <rect x="105" y="48" width="10" height="68" fill="#EF4444" />
            {/* Horizontal Beam */}
            <rect x="74" y="66" width="72" height="13" fill="#DC2626" />
            <rect x="76" y="68" width="68" height="9" fill="#EF4444" />

            {/* ICT Computer Workstation & Monitor (Top Right) */}
            <g transform="translate(124, 52)">
              {/* Monitor screen */}
              <rect x="0" y="0" width="22" height="16" rx="2" fill="#0F172A" stroke="#FFFFFF" strokeWidth="1" />
              <rect x="2" y="2" width="18" height="12" rx="1" fill="#38BDF8" />
              {/* Screen code/window lines */}
              <line x1="4" y1="5" x2="12" y2="5" stroke="#FFFFFF" strokeWidth="0.9" />
              <line x1="4" y1="8" x2="16" y2="8" stroke="#FBBF24" strokeWidth="0.9" />
              <line x1="4" y1="11" x2="10" y2="11" stroke="#FFFFFF" strokeWidth="0.9" />
              {/* Stand */}
              <rect x="9" y="16" width="4" height="4" fill="#64748B" />
              <rect x="6" y="19" width="10" height="2" rx="0.5" fill="#334155" />
              {/* Keyboard */}
              <rect x="2" y="22" width="18" height="3" rx="0.5" fill="#E2E8F0" stroke="#64748B" strokeWidth="0.5" />
            </g>

            {/* Students with Graduation Caps (Form Four Graduates) */}
            {/* Left Student: Boy Graduate */}
            <g transform="translate(72, 94)">
              {/* Head & Face */}
              <circle cx="18" cy="18" r="10" fill="#FDE68A" stroke="#0F172A" strokeWidth="0.8" />
              {/* Hair */}
              <path d="M 9 16 C 9 11, 27 11, 27 16 Z" fill="#0F172A" />
              {/* Eyes & Smile */}
              <circle cx="15" cy="18" r="1" fill="#0F172A" />
              <circle cx="21" cy="18" r="1" fill="#0F172A" />
              <path d="M 16 22 Q 18 24 20 22" stroke="#0F172A" strokeWidth="0.8" fill="none" />
              {/* Graduation Cap (Mortarboard) */}
              <polygon points="18,4 30,9 18,14 6,9" fill="#1E3A8A" stroke="#F59E0B" strokeWidth="0.6" />
              <rect x="12" y="9" width="12" height="3.5" fill="#1E3A8A" />
              {/* Tassel */}
              <line x1="18" y1="9" x2="28" y2="15" stroke="#F59E0B" strokeWidth="1" />
              {/* Gown / Body */}
              <path d="M 5 28 C 5 22, 31 22, 31 28 L 36 42 L 0 42 Z" fill="#1E3A8A" />
              {/* White Collar Shirt */}
              <polygon points="18,27 13,24 15,22 18,25 21,22 23,24" fill="#FFFFFF" />
              <polygon points="18,25 16,33 18,35 20,33" fill="#DC2626" />
            </g>

            {/* Right Student: Girl Graduate */}
            <g transform="translate(112, 94)">
              {/* Head & Face */}
              <circle cx="18" cy="18" r="10" fill="#FDE68A" stroke="#1E293B" strokeWidth="0.8" />
              {/* Hair (Longer Side Hair) */}
              <path d="M 8 16 C 8 8, 28 8, 28 16 L 29 23 L 26 23 L 26 18 C 26 13, 10 13, 10 18 L 10 23 L 7 23 Z" fill="#1E3A8A" />
              {/* Eyes & Smile */}
              <circle cx="15" cy="18" r="1" fill="#0F172A" />
              <circle cx="21" cy="18" r="1" fill="#0F172A" />
              <path d="M 16 22 Q 18 24 20 22" stroke="#0F172A" strokeWidth="0.8" fill="none" />
              {/* Graduation Cap (Mortarboard) */}
              <polygon points="18,4 30,9 18,14 6,9" fill="#1E3A8A" stroke="#F59E0B" strokeWidth="0.6" />
              <rect x="12" y="9" width="12" height="3.5" fill="#1E3A8A" />
              {/* Tassel */}
              <line x1="18" y1="9" x2="28" y2="15" stroke="#F59E0B" strokeWidth="1" />
              {/* Gown / Body */}
              <path d="M 5 28 C 5 22, 31 22, 31 28 L 36 42 L 0 42 Z" fill="#1E3A8A" />
              {/* White Collar & Bow */}
              <polygon points="18,27 13,24 15,22 18,25 21,22 23,24" fill="#FFFFFF" />
              <circle cx="18" cy="27" r="2" fill="#DC2626" />
            </g>
          </g>

          {/* 4. UPPER INNER BLUE ARC BANNER: UOMBONI */}
          <path
            d="M 52 68 C 78 48, 142 48, 168 68 L 160 80 C 138 64, 82 64, 60 80 Z"
            fill="#1E3A8A"
            stroke="#F59E0B"
            strokeWidth="1.4"
          />
          <text
            x="110"
            y="70"
            fontSize="13"
            fontWeight="900"
            fill="#FFFFFF"
            textAnchor="middle"
            letterSpacing="2.5"
          >
            UOMBONI
          </text>

          {/* 5. LOWER INNER BLUE ARC BANNER: SECONDARY SCHOOL */}
          <path
            d="M 50 134 C 78 158, 142 158, 170 134 L 163 123 C 138 144, 82 144, 57 123 Z"
            fill="#1E3A8A"
            stroke="#F59E0B"
            strokeWidth="1.4"
          />
          <text
            x="110"
            y="142"
            fontSize="10"
            fontWeight="900"
            fill="#FFFFFF"
            textAnchor="middle"
            letterSpacing="1.5"
          >
            SECONDARY SCHOOL
          </text>

          {/* 6. BOTTOM ROYAL BLUE CURVED BANNER: TUJIENDELEZE SISI WENYEWE */}
          <path
            d="M 22 150 C 58 184, 162 184, 198 150 L 188 137 C 156 168, 64 168, 32 137 Z"
            fill="url(#uomboniBlueBanner)"
            stroke="url(#uomboniGold)"
            strokeWidth="2"
          />
          <text fontSize="9.5" fontWeight="900" fill="#FEF08A" letterSpacing="0.8">
            <textPath href="#bottom-motto-path" startOffset="50%" textAnchor="middle">
              TUJIENDELEZE SISI WENYEWE
            </textPath>
          </text>

          {/* 7. BOTTOM PEDESTAL RIBBON: PRAYER • EDUCATION • WORK */}
          {/* Left Ribbon Tab: PRAYER */}
          <g transform="translate(18, 176)">
            <path
              d="M 0 4 L 48 4 L 44 20 L 0 20 L 6 12 Z"
              fill="url(#uomboniBlueBanner)"
              stroke="url(#uomboniGold)"
              strokeWidth="1.4"
            />
            <text x="24" y="15" fontSize="8.5" fontWeight="900" fill="#FFFFFF" textAnchor="middle" letterSpacing="0.5">
              PRAYER
            </text>
          </g>

          {/* Center Plaque: EDUCATION */}
          <g transform="translate(70, 172)">
            <rect
              x="0"
              y="0"
              width="80"
              height="22"
              rx="4"
              fill="url(#uomboniBlueBanner)"
              stroke="url(#uomboniGold)"
              strokeWidth="1.8"
            />
            <text x="40" y="15" fontSize="10.5" fontWeight="900" fill="#FEF08A" textAnchor="middle" letterSpacing="1.2">
              EDUCATION
            </text>
          </g>

          {/* Right Ribbon Tab: WORK */}
          <g transform="translate(154, 176)">
            <path
              d="M 0 4 L 48 4 L 42 12 L 48 20 L 0 20 Z"
              fill="url(#uomboniBlueBanner)"
              stroke="url(#uomboniGold)"
              strokeWidth="1.4"
            />
            <text x="24" y="15" fontSize="8.5" fontWeight="900" fill="#FFFFFF" textAnchor="middle" letterSpacing="0.5">
              WORK
            </text>
          </g>
        </svg>
        )}
      </div>

      {showText && (
        <div>
          <div className="flex items-center gap-1.5">
            <h1 className={`font-black tracking-tight leading-none ${size === 'lg' || size === 'xl' || size === '2xl' ? 'text-lg sm:text-xl' : 'text-sm sm:text-base'} ${variant === 'light' ? 'text-white' : 'text-slate-900'}`}>
              UOMBONI SECONDARY
            </h1>
          </div>
          <p className="text-[10px] sm:text-[11px] font-bold text-amber-500 uppercase tracking-widest leading-tight">
            Tujiendeleze Sisi Wenyewe
          </p>
          <p className={`text-[9px] font-medium leading-none mt-0.5 ${variant === 'light' ? 'text-emerald-300' : 'text-slate-500'}`}>
            Catholic Diocese of Moshi • NECTA S0486
          </p>
        </div>
      )}
    </div>
  );
};

